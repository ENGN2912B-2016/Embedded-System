#include "widget.h"
#include "ui_widget.h"
#include <QtMultimedia/QAudioDeviceInfo>
#include <QtMultimedia/QAudioInput>
#include <QtMultimedia/QAudioOutput>
#include <QCoreApplication>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QChart>
#include <QtWidgets/QVBoxLayout>
#include <qcustomplot.h>
#include <QDir>
#include <QFile>
#include <QLabel>
#include <iostream>
#include <QSound>
#include <string>
#include <QString>
#include <Qvector>

#include "IOdevice.h"

QT_CHARTS_USE_NAMESPACE
using namespace std;

Widget::Widget(QWidget *parent)
    : QWidget(parent),
      mic(0),
      input_plot(0),
      output_plot(0),
      dataseries(0),
      dataseries2(0),
      audioInput(0),
      ui(new Ui::Widget)
{

    ui->setupUi(this);
    initialize_GUI();
}

Widget::~Widget()
{
    audioInput->stop();
    mic->close();
    speaker->close();
}

void Widget::initialize_GUI()
{
    // Display for input sound waves
    input_plot = new QChart;
    QChartView *InputView = new QChartView(input_plot);
    InputView->setMinimumSize(600, 200);
    dataseries = new QLineSeries;
    input_plot->addSeries(dataseries);
    QValueAxis *axisX_in = new QValueAxis;
    axisX_in->setRange(0, 2000);
    axisX_in->setLabelFormat("%g");
    axisX_in->setTitleText("Samples");
    QValueAxis *axisY_in = new QValueAxis;
    axisY_in->setRange(-2, 2);
    axisY_in->setTitleText("Amplitude");
    input_plot->setAxisX(axisX_in, dataseries);
    input_plot->setAxisY(axisY_in, dataseries);
    input_plot->legend()->hide();
    input_plot->setTitle("Sound waves from microphone");


    // Display for output signals
    ui->widget->setMinimumSize(550, 150);
    ui->widget->xAxis->setLabel("Samples");
    ui->widget->yAxis->setLabel("Amplitude");
    ui->widget->plotLayout()->insertRow(0);
    ui->widget->plotLayout()->addElement(0, 0, new QCPTextElement(ui->widget, "Voice Activity Detection", QFont("default", 10)));

    ui->widget_2->setMinimumSize(550, 150);
    ui->widget_2->xAxis->setLabel("Samples");
    ui->widget_2->yAxis->setLabel("Amplitude");
    ui->widget_2->plotLayout()->insertRow(0);
    ui->widget_2->plotLayout()->addElement(0, 0, new QCPTextElement(ui->widget_2, "Modulated Audio", QFont("default", 10)));



    // Push Buttons
    // Start button: starts recording audio and displaying input signal
    // Stop button: stopd recording and displaying signals
    // Freq select: toggle button that allows ser to input frequency parameters
    QPushButton *start_button = new QPushButton("Start Recording",this);
    start_button->setStyleSheet("background-color:green;");
    QPushButton *stop_button = new QPushButton("Stop Recording",this);
    stop_button->setStyleSheet("background-color:red;");

    QWidget *widget = new QWidget();
    QPushButton *play_button = new QPushButton(this);
    play_button->setMinimumWidth(200);
    play_button->setText("Play");
    Text1=new QTextEdit();
    Text1->setMinimumHeight(25);
    Text1->setText("1.0");
    QGridLayout * layout = new QGridLayout(widget);
    QFont font1("Default",10,BOLD_FONTTYPE);
    QFont font2("Default",8);
    QLabel *label1= new QLabel("Modulation Ratio");
    label1->setFont(font1);
    QLabel *label2= new QLabel("*Suggested ratio: 0.6-2.3 for intelligable speech.");
    label2->setFont(font2);
    layout->addWidget(label1,0,0);
    layout->addWidget(Text1,0,1);
    layout->addWidget(label2,1,1);

    QWidget *widget1 = new QWidget();
    QGridLayout * layout1 = new QGridLayout(widget1);
    layout1->addWidget(start_button,0,0);
    layout1->addWidget(stop_button,0,1);
    layout1->addWidget(play_button,0,2);


    Text2=new QTextEdit();
    Text2->setMinimumHeight(25);
    Text2->setText("Audio Program started.");

    // Main GUI box
    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(InputView);
    mainLayout->addWidget(ui->widget);
    mainLayout->addWidget(ui->widget_2);
    mainLayout->addWidget(widget);
    mainLayout->addWidget(widget1);
    mainLayout->addWidget(new QLabel("Message Box:"));
    mainLayout->addWidget(Text2);
    setLayout(mainLayout);

    // Connect button signal to appropriate slot
    connect(start_button, SIGNAL (released()), this, SLOT (handleStart()));
    connect(stop_button, SIGNAL (released()), this, SLOT (handleStop()));
    connect(play_button, SIGNAL (released()), this, SLOT (handlePlay()));

}


void Widget::handleStart()
{
    if (toggle==0)
    {
    Write_scale();
    qDebug()<<"Recording from...";
    Text2->setText("Recording from mic...");
    outputfile.setFileName("/audio_qt.raw");
    outputfile.open( QIODevice::WriteOnly | QIODevice::Truncate );
    QAudioFormat formatAudio;
    formatAudio.setSampleRate(44100);
    formatAudio.setChannelCount(1);
    formatAudio.setSampleSize(8);
    formatAudio.setCodec("audio/pcm");
    formatAudio.setByteOrder(QAudioFormat::LittleEndian);
    formatAudio.setSampleType(QAudioFormat::UnSignedInt);

    QAudioDeviceInfo inputDevices = QAudioDeviceInfo::defaultInputDevice();
    audioInput = new QAudioInput(inputDevices,formatAudio, this);
    audioRecord=new QAudioRecorder(this);
    qDebug()<<inputDevices.deviceName();

    QAudioEncoderSettings audioSettings;
    audioSettings.setCodec("audio/pcm");
    audioSettings.setQuality(QMultimedia::HighQuality);
    audioSettings.setSampleRate(44100);
    mic = new IOdevice(dataseries, this);
    mic->open(QIODevice::WriteOnly);

    start= clock();

    QString path = QDir::currentPath();
    path.append("/syncFiles/input");

    audioInput->start(mic);
    audioRecord->setEncodingSettings(audioSettings);
    audioRecord->setOutputLocation(QUrl::fromLocalFile(path));
    audioRecord->record();
    toggle=1;
    }
    else{
        qWarning()<<"Recording in process. Please stop recording to save new file.";
        Text2->setText("Recording in process. Please stop recording to save new file.");
    }
}

void Widget::handleStop()
{
    if (toggle==1){
        finish=clock();
    int time=finish-start;
    if (time<=5000)
    {
       qWarning()<<"Recording less than 5 seconds.";
       audioInput->stop();
       QMessageBox msgBox;
       msgBox.setText("Recording had to be longer than 5 seconds. Please record again.");
       msgBox.exec();
       //audioRecord->stop();
       dataseries->clear();
       outputfile.close();
       delete audioInput;
       delete audioRecord;
    }
    else
    {
        Text2->setText("Recording stopped successfully.");
        qDebug()<<"Stopping mic...";
        audioInput->stop();
        audioRecord->stop();
        dataseries->clear();
        outputfile.close();
        delete audioInput;
        delete audioRecord;
    }
    toggle=0;
    }
    else{
        qWarning()<<"No recording started. Please start recording to save a new file";
        Text2->setText("No recording started. Please start recording to save a new file");
    }
}



void Widget::handlePlay()
{
    Play();
    Read_File(ui->widget,ui->widget_2);
}

void Widget::Read_File(QCustomPlot *widget,QCustomPlot *widget_2)
{
    Text2->setText("Audio Program started.");
    QVector<double>VAD_data;
    QVector<double>VAD_samples;
    QVector<double>MOD_data;
    QVector<double>MOD_samples;
    QVector<double>data;
    QVector<double>samples;

    QString path = QDir::currentPath();
    double sample=0;
    path.append("/syncFiles/outputVAD.txt");
    QFile VADfile(path);
    if (VADfile.open(QFile::ReadOnly | QFile::Text))
    {
    QTextStream ReadVADFile(&VADfile);
    while(!ReadVADFile.atEnd())
     {
            QString line = ReadVADFile.readLine();
            VAD_data.push_back(line.toDouble());
            sample=sample+1;
            samples.push_back(sample);
            samplecount=samplecount+1;
     }
    VADfile.close();
    cout<<"File read.."<<endl;

    path = QDir::currentPath();
    path.append("/syncFiles/outputMOD.txt");
    QFile MODfile(path);
    if (MODfile.open(QFile::ReadOnly | QFile::Text))
    {
    QTextStream ReadMODFile(&MODfile);
    while(!ReadMODFile.atEnd())
     {
            QString line = ReadMODFile.readLine();
            MOD_data.push_back(line.toDouble());
     }
   MODfile.close();
   path = QDir::currentPath();
   QFile file(path.append("/syncFiles/input.txt"));
   if (file.open(QFile::ReadOnly | QFile::Text)){
   QTextStream ReadFile(&file);
   while(!ReadFile.atEnd())
    {
           QString line = ReadFile.readLine();
           data.push_back(line.toDouble());

    }
   file.close();

   qDebug()<<"File read..";
   // assign data to graph
   widget->addGraph();
   widget->graph(0)->setPen(QPen(Qt::blue));
   widget->graph(0)->setData(samples, VAD_data);
   widget->graph(0)->setName("VAD Output");

   widget->addGraph(widget->xAxis2, widget->yAxis2);
   widget->graph(1)->setPen(QPen(Qt::red));
   widget->graph(1)->setData(samples, data);
   widget->graph(1)->setName("Input Audio");
   widget->legend->setVisible(true);
   widget->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignBottom|Qt::AlignLeft);
   cout<<"VAD set again"<<endl;
   widget_2->addGraph();
   widget_2->graph(0)->setData(samples, MOD_data);

   // set axes ranges, so we see all data:
   widget->xAxis->setRange(0, VAD_data.size());
   widget->yAxis->setRange(-2, 2.1);
   widget->xAxis2->setRange(0, MOD_data.size());
   widget->yAxis2->setRange(-2, 2.1);
   widget_2->graph(0)->setPen(QPen(Qt::blue));
   widget_2->xAxis->setRange(0, MOD_data.size());
   widget_2->yAxis->setRange(-2, 2);

   ui->widget->replot();
   ui->widget_2->replot();

   qDebug()<<"Plotting completed";
    }
    else
    {
        QMessageBox msgBox;
        msgBox.setText("Error reading OutputVAD.txt. File not found.");
        msgBox.exec();
    }
    }
    else{
        QMessageBox msgBox;
        msgBox.setText("Error reading OutputMOD.txt. File not found.");
        msgBox.exec();
    }}
    else{
        QMessageBox msgBox;
        msgBox.setText("Error reading input.txt. File not found.");
        msgBox.exec();
    }

}

void Widget::Write_scale()
{
    QString path = QDir::currentPath();
    QFile file(path.append("/syncFiles/scale.txt"));
    if(file.open(QFile::ReadWrite))
    {
        QString input = Text1->toPlainText();
        double scale=input.toDouble();
        QTextStream out(&file);
        out<<scale<<endl;
    }
    else
    {
        qWarning()<<"Could not save frequency scale. Output file does not exist";
    }
}

void Widget::Play()
{
    Text2->setText("Playing sound file.");
    QString path = QDir::currentPath();
    QFile audio_file(path.append("/syncFiles/output.wav"));

        if(audio_file.open(QIODevice::ReadOnly))
        {
            qDebug()<<"Playing sound from...";
            QAudioDeviceInfo info(QAudioDeviceInfo::defaultOutputDevice());
            qDebug() << info.deviceName();
            QSound::play(path);
        }

        else
        {
            qWarning()<<"Could not open sound file.Invalid file/format.";
        }

}


