//Define headers
#include <iostream>
#include <fftw3.h> //fft
#include <math.h>
#include <vector>
#include <numeric> //accumulate, inner_product
#include <algorithm> //max_element, fill, copy
#include <fstream>
#include <cassert>
#include <functional> //transform
#include "fft.h"
#include "AudioProcessing.h"
using namespace std;

//Arithmatic mean
double mean(vector<double> data)
{
	return accumulate(data.begin(), data.end(), 0.0) / data.size();
}

//Check if negative value
bool isNegative(double i)
{
	if (i < 0) return 1;
	else return 0;
}

//Apply hamming window to a vector
vector<double> hammWin(vector<double> const data)
{
	vector<double> winOutput(data.size());
	double alpha = 0.54;
	double beta = 1.0 - alpha;
	for (int n = 0; n < data.size(); n++)
	{
		winOutput[n] = data[n] * (alpha - beta*cos((2.0 * pi*n) / (data.size() - 1)));
	}
	return winOutput;
}

//Calculate energy of a signal
double energy(vector<double> const data)
{
	return inner_product(data.begin(), data.end(), data.begin(), 0.0);
}

//Load text data into a vector
void load_vec(const string &filename, vector<double> &vec)
{
	ifstream infile(filename);
	assert(infile.is_open());
	double value;
	while (infile >> value) {
		vec.push_back(value);
	}
	infile.close();
}

//Save vector data into a text file
void save_vec(const string &filename, vector<double> &vec)
{
	ofstream outfile(filename);
	assert(outfile.is_open());
	for (vector<double>::const_iterator it = vec.begin(); it != vec.end(); ++it)
	{
		outfile << *it << '\n';
	}
	outfile.close();
}

//Caculate noise spectrum for spectral subtraction and noise energy
double setThresh(vector<double> const data, int const numFrame, vector<double> &n_frame_abs)
{
	double eThresh = 0.0;
	vector<double> winFrame(frameSize);
	vector<double> fft_abs(nyq, 0.0);

	for (int k = 0; k < numFrame; k++)
	{
		vector<double> frame(&data[k*(frameSize - overlapSize)], &data[((k + 1)*frameSize) - (k*overlapSize)]);
		winFrame = hammWin(frame);
		fft FFT(winFrame);
		fft_abs = FFT.getWholeAbs();
		eThresh += FFT.energy();
		transform(fft_abs.begin(), fft_abs.end(), n_frame_abs.begin(), n_frame_abs.begin(), plus<double>());
	}

	eThresh /= static_cast<double>(numFrame);
	transform(n_frame_abs.begin(), n_frame_abs.end(), n_frame_abs.begin(), bind1st(multiplies<double>(), 1.0 / static_cast<double>(numFrame)));

	return eThresh;
}

//Compute VAD
fft vad(vector<double> const data, vector<double> const nSpec, double eThresh, vector<double> &vadOutput, int const frameIdx, bool &vadLogical)
{
	vector<double> winFrame = hammWin(data);
	fft FFT(winFrame);
	vector<double> fft_abs = FFT.getWholeAbs();
	vector<double> fft_specSub(nyq, 0.0);

	transform(fft_abs.begin(), fft_abs.end(), nSpec.begin(), fft_specSub.begin(), minus<double>());
	replace_if(fft_specSub.begin(), fft_specSub.end(), isNegative, 0.0);

	double eTemp = energy(fft_specSub);
	double fTemp = (max_element(fft_specSub.begin(), fft_specSub.end()) - fft_specSub.begin())*(Fs / static_cast<double>(nyq));


	if ((eTemp > eThresh) && (fTemp > fThresh))
	{
		fill(vadOutput.begin() + (frameIdx*(frameSize - overlapSize)), vadOutput.begin() + (((frameIdx + 1)*frameSize) - (frameIdx*overlapSize)), 1);
		vadLogical = 1;
	}
	else
	{
		fill(vadOutput.begin() + (frameIdx*(frameSize - overlapSize)), vadOutput.begin() + (((frameIdx + 1)*frameSize) - (frameIdx*overlapSize)), 0);
		vadLogical = 0;
	}
	return FFT;
}

//Modulate audio
void mod(vector<double> data, double const modR, vector<double> &modOutput, bool const vadResult, int const frameIdx, fft frameSpec)
{
	if (vadResult && modR != 1.0)
	{
		double ifft[frameSize] = { 0 };
		fftw_complex fft_mod[nyq] = { 0 };

		int maxIdx;

		if (modR <= 1.0) maxIdx = nyq;
		else maxIdx = floor(data.size() / (2.0*modR));

		for (int k = 0; k < maxIdx; k++)
		{
			fft_mod[static_cast<int>(modR*k)][0] += frameSpec.getReal(k);
			fft_mod[static_cast<int>(modR*k)][1] += frameSpec.getImag(k);
		}

		fftw_plan iplan = fftw_plan_dft_c2r_1d(frameSize, &fft_mod[0], ifft, FFTW_ESTIMATE);
		fftw_execute(iplan);
		for (int k = 0; k < frameSize; k++) ifft[k] /= static_cast<double>(frameSize);
		copy(ifft, ifft + sizeof(ifft) / sizeof(ifft[0]), modOutput.begin() + (frameIdx*(frameSize - overlapSize)));
		fftw_destroy_plan(iplan);
	}
	else if (vadResult && modR == 1.0)
	{
		copy(data.begin(), data.end(), modOutput.begin() + (frameIdx*(frameSize - overlapSize)));
	}
	else
	{
		fill(modOutput.begin() + (frameIdx*(frameSize - overlapSize)), modOutput.begin() + (((frameIdx + 1)*frameSize) - (frameIdx*overlapSize)), 0);
	}

}