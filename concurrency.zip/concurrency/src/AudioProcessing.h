#pragma once
//Define headers
#include <vector>
#include "fft.h"
using namespace std;

//Declare constants - change the first four if you want to use a different Fs
#define Fs 44100.0 //audio sampling rate
#define frameSize 1764 //40 ms frames
#define overlapSize 177 //10% overlap 
#define nyq 883 //nyquist for fft
#define pi 3.141592653589793
#define fThresh 200.0 //threshold for dominant frequency

//Arithmatic mean
double mean(vector<double> data);

//Check if negative value
bool isNegative(double i);

//Apply hamming window to a vector
vector<double> hammWin(vector<double> const data);

//Calculate energy of a signal
double energy(vector<double> const data);

//Load text data into a vector
void load_vec(const string &filename, vector<double> &vec);

//Save vector data into a text file
void save_vec(const string &filename, vector<double> &vec);

//Caculate noise spectrum for spectral subtraction and noise energy
double setThresh(vector<double> const data, int const numFrame, vector<double> &n_frame_abs);

//Compute VAD
fft vad(vector<double> const data, vector<double> const nSpec, double eThresh, vector<double> &vadOutput, int const frameIdx, bool &vadLogical);

//Modulate audio
void mod(vector<double> data, double const modR, vector<double> &modOutput, bool const vadResult, int const frameIdx, fft frameSpec);