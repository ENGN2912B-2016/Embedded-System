//Create an fft class - this is very specific to its use in this program
#ifndef fft_h_
#define fft_h_

#include <complex.h>
#include <math.h>
#include <fftw3.h>
#include <numeric>

#define frameSize 1764 //40 ms frames
#define nyq 883 //nyquist for fft

using namespace std;

class fft
{
public:
	//Constructors
	fft() {
		data_ = vector<double>(0);
		fftAbs_ = vector<double>(0);
		for (int i = 0; i < nyq; i++) {
			fftReg_[i][0] = 0;
			fftReg_[i][1] = 0;
		}
	};
	fft(const fft& other) : data_(other.data_), fftAbs_(other.fftAbs_) {
		for (int i = 0; i < nyq; i++) {
			fftReg_[i][0] = other.fftReg_[i][0];
			fftReg_[i][1] = other.fftReg_[i][1];
		}
	}
	fft(const vector<double> &c)
	{
		data_ = c;
		fftAbs_ = vector<double>(0);
		for (int i = 0; i < nyq; i++) {
			fftReg_[i][0] = 0;
			fftReg_[i][1] = 0;
		}
		fftw_plan plan = fftw_plan_dft_r2c_1d(frameSize, &data_[0], fftReg_, FFTW_ESTIMATE);
		fftw_execute(plan);

		for (int j = 0; j < nyq; j++)
		{
			fftAbs_.push_back(sqrt(pow(fftReg_[j][0], 2) + pow(fftReg_[j][1], 2)));
		}
		fftw_destroy_plan(plan);
	};

	//Destructor
	~fft() {};

	fft& operator= (const fft& other) {
		data_ = other.data_;
		fftAbs_ = other.fftAbs_;
		for (int i = 0; i < nyq; i++) {
			fftReg_[i][0] = other.fftReg_[i][0];
			fftReg_[i][1] = other.fftReg_[i][1];
		}
		return *this;
	}

	//Accesors
	double getReal(int idx)
	{
		return fftReg_[idx][0];
	}

	double getImag(int idx)
	{
		return fftReg_[idx][1];
	}

	double getAbs(int idx)
	{
		return fftAbs_[idx];
	}

	vector<double> getWholeAbs()
	{
		return fftAbs_;
	}

	double energy()
	{
		return inner_product(fftAbs_.begin(), fftAbs_.end(), fftAbs_.begin(), 0.0);
	}


private:
	vector<double> data_;
	vector<double> fftAbs_;
	fftw_complex fftReg_[nyq];
};
#endif