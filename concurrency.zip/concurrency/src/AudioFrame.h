#pragma once
#ifndef AudioFrame_h_
#define AudioFrame_h_

#include <vector>
#include "fft.h"
using namespace std;

class AudioFrame
{
public:
	AudioFrame() {
		inputFrame = vector<double>(0);
		frameFFT = fft();
		eThresh = 0;
		ratio = 1;
		VADlogical = false;
		frameIndex = 0;

	};
	AudioFrame(const AudioFrame& a) : inputFrame(a.inputFrame), frameFFT(a.frameFFT), eThresh(a.eThresh), 
										ratio(a.ratio), VADlogical(a.VADlogical), frameIndex(a.frameIndex) {};

	AudioFrame& operator=(const AudioFrame& a) {
		inputFrame = a.inputFrame;
		frameFFT= a.frameFFT;
		eThresh= a.eThresh;
		ratio = a.ratio;
		VADlogical = a.VADlogical;
		frameIndex = a.frameIndex;
		return *this;
	}

	vector<double>& getInputFrame() { return inputFrame; };
	fft& getFrameFFT() { return frameFFT; };
	double getEThresh() { return eThresh; };
	double getRatio() { return ratio; };
	bool getVADlogical() { return VADlogical; };
	int getFrameIndex() { return frameIndex; };

	void setInputFrame(vector<double> f) { inputFrame = f; };
	void setFrameFFT(fft f) { frameFFT = f; };
	void setEThresh(double e) { eThresh = e; };
	void setRatio(double r) { ratio = r; };
	void setVADlogical(bool v) { VADlogical = v; };
	void setFrameIndex(int k) { frameIndex = k; };

private:
	vector<double> inputFrame;
	fft frameFFT;
	double eThresh, ratio;
	bool VADlogical;
	int frameIndex;
};

#endif