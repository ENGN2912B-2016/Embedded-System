#include <atomic>
#include <thread>
#include <iostream>
#include <vector>
#include <algorithm>
#include <fftw3.h>
#include "AudioFrame.h"
#include "AudioProcessing.h"
#include "ConcurrentQueue.h"

concurrent_queue<AudioFrame> inqueue, modqueue;
atomic<bool> done(false);
atomic_int incount(0);
atomic_int VADcount(0);
atomic_int Modcount(0);

using namespace std;

void inputThread(vector<double> input, int delay, int numFrames, double ratio, double eThresh) {
	incount = 0;
	for (int i = delay; i < numFrames - 1; i++) {
			AudioFrame a;
			a.setEThresh(eThresh);
			a.setRatio(ratio);
			a.setFrameIndex(i);
			vector<double> frame(&input[i*(frameSize - overlapSize)], &input[((i + 1)*frameSize) - (i*overlapSize)]);
			a.setInputFrame(frame);
			inqueue.push(a);
			incount++;
			//cout << "in: " << incount << endl;
	}
}

void vadThread(vector<double> &outputVAD, vector<double> noiseSpectrum) {
	VADcount = 0;
		while (!done || VADcount < incount) {
			bool tempVADLogical = false;
			AudioFrame b;
			inqueue.wait_and_pop(b);
			AudioFrame a = b;
			fft frameFFT = vad(a.getInputFrame(), noiseSpectrum, a.getEThresh(), outputVAD, a.getFrameIndex(), tempVADLogical);
			a.setFrameFFT(frameFFT);
			a.setVADlogical(tempVADLogical);
			VADcount++;
			modqueue.push(a);
			//cout << "vad: " << VADcount << endl;
		}
}

void modulationThread(vector<double> &outputMOD) {
	Modcount = 0;
	while (!done || Modcount < incount) {
		AudioFrame b;
		modqueue.wait_and_pop(b);
		AudioFrame a = b;
		mod(a.getInputFrame(), a.getRatio(), outputMOD, a.getVADlogical(), a.getFrameIndex(), a.getFrameFFT());
		Modcount++;
		//cout << "mod: " << Modcount << endl;
	}
}

//void outputThread(void) {
//	AudioFrame value;
//	vector<int> audiovec;
//	while (!done) {
//		while (outqueue.pop(value)) {
//			outcount++;
//			audiovec = value.getData();
//			cout << audiovec.front() << endl;
//		}
//	}
//}

int main(int argc, char** argv) {

	//Load input data
	vector<double> input, r;
	string filenameInput = "input.txt";
	load_vec(filenameInput, input);
	string filenameRatio = "modRatio.txt";
	load_vec(filenameRatio, r);

	//Remove DC offset from signal
	double dc = mean(input);
	for (vector<double>::iterator it = input.begin(); it != input.end(); ++it)
	{
		*it -= dc;
	}

	//Calculate number of 40 ms overlapping frames
	int numFrames = ceil((static_cast<double>(input.size() - frameSize) / static_cast<double>(frameSize - overlapSize)) + 1.0);

	//Calculate num of frames of silence, assume 5 seconds
	int delay = floor((Fs * 5.0) / static_cast<double>(frameSize - overlapSize));


	//Pad input with zeros if data is not an integer number of frames
	if (input.size() % (frameSize - overlapSize))
	{
		vector<double> zeroPad((((numFrames - 1)*(frameSize - overlapSize)) + frameSize) - input.size(), 0);
		input.insert(input.end(), zeroPad.begin(), zeroPad.end());
	}

	//Instantiate output arrays
	vector<double> outputVAD(input.size());
	vector<double> outputMOD(input.size());

	//Allocate memory for noise spectrum and frame VAD output 
	vector<double> noiseSpectrum(nyq, 0.0); //absolute fft of all noise frames

	//Set thresholds for vad
	double eThresh = setThresh(input, delay, noiseSpectrum);
	done = false;
	thread tin{ bind(inputThread, input, delay,  numFrames, r[0], eThresh)};
	thread tvad{ bind(vadThread, ref(outputVAD), noiseSpectrum) };
	thread tmod{ bind(modulationThread, ref(outputMOD)) };

	tin.join();
	done = true;
	tvad.join();
	tmod.join();

	string filenameVad = "outputVAD.txt";
	save_vec(filenameVad, outputVAD);

	string filenameMod = "outputMOD.txt";
	save_vec(filenameMod, outputMOD);

	return 0;
}