//Define headers
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fftw3.h> //fft
#include <math.h>
#include <vector>
#include <numeric> //accumulate, inner_product
#include <algorithm> //max_element, fill, copy
#include <fstream>
#include <cassert>
#include <functional> //transform
using namespace std;


#include <stdio.h>  /* defines FILENAME_MAX */
#ifdef WINDOWS
#include <direct.h>
#define GetCurrentDir _getcwd
#else
#include <unistd.h>
#define GetCurrentDir getcwd
#endif
#include<iostream>

string GetCurrentWorkingDir(void) {
    char buff[FILENAME_MAX];
    GetCurrentDir(buff, FILENAME_MAX);
    std::string current_working_dir(buff);
    return current_working_dir;
}

//Declare constants - change the first four if you want to use a different Fs
#define Fs 44100.0 //audio sampling rate
#define frameSize 1764 //40 ms frames
#define overlapSize 177 //10% overlap
#define nyq 883 //nyquist for fft
#define pi 3.141592653589793
#define fThresh 200.0 //threshold for dominant frequency


//Create struct framework to hold .wav information
struct wavInfo
{
	char ChunkID[4], Format[4], Subchunk1ID[4], Subchunk2ID[4];
	int ChunkSize, Subchunk1Size, SampleRate, ByteRate, Subchunk2Size;
	short AudioFormat, NumChannels, BlockAlign, BitsPerSample;
	vector<double> data;
	short *dataPointer;
};

//Create function to read .wav data into a vector. NOTE: this code was customized from:http://forums.codeguru.com/showthread.php?460547-Reading-amp-Writing-wav-file
struct wavInfo readWav(const char *filename)
{
	struct wavInfo inputWav;
	// Read the wave file
	FILE *fhandle = fopen(filename, "rb");
	fread(inputWav.ChunkID, 1, 4, fhandle);
	fread(&inputWav.ChunkSize, 4, 1, fhandle);
	fread(inputWav.Format, 1, 4, fhandle);
	fread(inputWav.Subchunk1ID, 1, 4, fhandle);
	fread(&inputWav.Subchunk1Size, 4, 1, fhandle);
	fread(&inputWav.AudioFormat, 2, 1, fhandle);
	fread(&inputWav.NumChannels, 2, 1, fhandle);
	fread(&inputWav.SampleRate, 4, 1, fhandle);
	fread(&inputWav.ByteRate, 4, 1, fhandle);
	fread(&inputWav.BlockAlign, 2, 1, fhandle);
	fread(&inputWav.BitsPerSample, 2, 1, fhandle);
	fread(&inputWav.Subchunk2ID, 1, 4, fhandle);
	fread(&inputWav.Subchunk2Size, 4, 1, fhandle);
	inputWav.dataPointer = new short[inputWav.Subchunk2Size / (inputWav.BitsPerSample / 8)]; // Create an element for every sample
	fread(inputWav.dataPointer, inputWav.BitsPerSample / 8, inputWav.Subchunk2Size / (inputWav.BitsPerSample / 8), fhandle); // Reading raw audio data
	fclose(fhandle);

	for (int k = 0; k < inputWav.Subchunk2Size / 2; k++)
	{
		inputWav.data.push_back(*inputWav.dataPointer / (pow(2, inputWav.BitsPerSample) / 2));
		inputWav.dataPointer++;
	}

	return inputWav;
}

//Create function to write a vector to .wav. NOTE: this code was customized from:http://forums.codeguru.com/showthread.php?460547-Reading-amp-Writing-wav-file
void writeWav(const char *filename, struct wavInfo info, vector<double> data)
{
	vector<short> temp;
	for (int k = 0; k < data.size(); k++)
	{
		temp.push_back(static_cast<short>(data[k] * (pow(2, info.BitsPerSample) / 2)));
	}

	FILE *fhandle = fopen(filename, "wb");
	fwrite(info.ChunkID, 1, 4, fhandle);
	fwrite(&info.ChunkSize, 4, 1, fhandle);
	fwrite(info.Format, 1, 4, fhandle);
	fwrite(info.Subchunk1ID, 1, 4, fhandle);
	fwrite(&info.Subchunk1Size, 4, 1, fhandle);
	fwrite(&info.AudioFormat, 2, 1, fhandle);
	fwrite(&info.NumChannels, 2, 1, fhandle);
	fwrite(&info.SampleRate, 4, 1, fhandle);
	fwrite(&info.ByteRate, 4, 1, fhandle);
	fwrite(&info.BlockAlign, 2, 1, fhandle);
	fwrite(&info.BitsPerSample, 2, 1, fhandle);
	fwrite(&info.Subchunk2ID, 1, 4, fhandle);
	fwrite(&info.Subchunk2Size, 4, 1, fhandle);
	fwrite(&temp[0], info.BitsPerSample / 8, info.Subchunk2Size / (info.BitsPerSample / 8), fhandle);
	fclose(fhandle);
}


//Arithmatic mean
double mean(vector<double> data)
{
	return accumulate(data.begin(), data.end(), 0.0) / data.size();
}

//Check if negative value
bool isNegative(double i)
{
	if (i < 0) return 1;
	else return 0;
}

//Apply hamming window to a vector
vector<double> hammWin(vector<double> const data)
{
	vector<double> winOutput(data.size());
	double alpha = 0.54;
	double beta = 1.0 - alpha;
	for (int n = 0; n < data.size(); n++)
	{
		winOutput[n] = data[n] * (alpha - beta*cos((2.0 * pi*n) / (data.size() - 1)));
	}
	return winOutput;
}

//Calculate energy of a signal
double energy(vector<double> const data)
{
	return inner_product(data.begin(), data.end(), data.begin(), 0.0);
}

//Load text data into a vector
void load_vec(const string &filename, vector<double> &vec)
{
	ifstream infile(filename.c_str());
	assert(infile.is_open());
	double value;
	while (infile >> value) {
		vec.push_back(value);
	}
	infile.close();
}

//Save vector data into a text file
void save_vec(const string &filename, vector<double> &vec)
{
	ofstream outfile(filename.c_str());
	assert(outfile.is_open());
	for (vector<double>::const_iterator it = vec.begin(); it != vec.end(); ++it)
	{
		outfile << *it << '\n';
	}
	outfile.close();
}


//Create an fft class - this is very specific to its use in this program
#ifndef fft_h_
#define fft_h_
class fft
{
public:
	//Constructors
	fft() {};
	fft(const vector<double> &c)
	{
		data_ = c;
		fftw_plan plan = fftw_plan_dft_r2c_1d(frameSize, &data_[0], fftReg_, FFTW_ESTIMATE);
		fftw_execute(plan);
		fftw_destroy_plan(plan);

		for (int j = 0; j < nyq; j++)
		{
			fftAbs_.push_back(sqrt(pow(fftReg_[j][0], 2) + pow(fftReg_[j][1], 2)));
		}
	};

	//Destructor
	~fft() {};

	//Accesors
	double getReal(int idx)
	{
		return fftReg_[idx][0];
	}

	double getImag(int idx)
	{
		return fftReg_[idx][1];
	}

	double getAbs(int idx)
	{
		return fftAbs_[idx];
	}

	vector<double> getWholeAbs()
	{
		return fftAbs_;
	}

	double energy()
	{
		return inner_product(fftAbs_.begin(), fftAbs_.end(), fftAbs_.begin(), 0.0);
	}


private:
	vector<double> data_;
	vector<double> fftAbs_;
	fftw_complex fftReg_[nyq];

};
#endif


//Caculate noise spectrum for spectral subtraction and noise energy
double setThresh(vector<double> const data, int const numFrame, vector<double> &n_frame_abs)
{
	double eThresh = 0.0;
	vector<double> winFrame(frameSize);
	vector<double> fft_abs(nyq, 0.0);

	for (int k = 0; k < numFrame; k++)
	{
		vector<double> frame(&data[k*(frameSize - overlapSize)], &data[((k + 1)*frameSize) - (k*overlapSize)]);
		winFrame = hammWin(frame);
		fft FFT(winFrame);
		fft_abs = FFT.getWholeAbs();
		eThresh += FFT.energy();
		transform(fft_abs.begin(), fft_abs.end(), n_frame_abs.begin(), n_frame_abs.begin(), plus<double>());
	}

	eThresh /= static_cast<double>(numFrame);
	transform(n_frame_abs.begin(), n_frame_abs.end(), n_frame_abs.begin(), bind1st(multiplies<double>(), 1.0 / static_cast<double>(numFrame)));

	return eThresh;
}

//Compute VAD
fft vad(vector<double> const data, vector<double> const nSpec, double eThresh, vector<double> &vadOutput, int const frameIdx, bool &vadLogical)
{
	vector<double> winFrame = hammWin(data);
	fft FFT(winFrame);
	vector<double> fft_abs = FFT.getWholeAbs();
	vector<double> fft_specSub(nyq, 0.0);

	transform(fft_abs.begin(), fft_abs.end(), nSpec.begin(), fft_specSub.begin(), minus<double>());
	replace_if(fft_specSub.begin(), fft_specSub.end(), isNegative, 0.0);

	double eTemp = energy(fft_specSub);
	double fTemp = (max_element(fft_specSub.begin(), fft_specSub.end()) - fft_specSub.begin())*(Fs / static_cast<double>(nyq));


	if ((eTemp > eThresh) && (fTemp > fThresh))
	{
		fill(vadOutput.begin() + (frameIdx*(frameSize - overlapSize)), vadOutput.begin() + (((frameIdx + 1)*frameSize) - (frameIdx*overlapSize)), 1);
		vadLogical = 1;
	}
	else
	{
		fill(vadOutput.begin() + (frameIdx*(frameSize - overlapSize)), vadOutput.begin() + (((frameIdx + 1)*frameSize) - (frameIdx*overlapSize)), 0);
		vadLogical = 0;
	}
	return FFT;
}

//Modulate audio
void mod(vector<double> data, double const modR, vector<double> &modOutput, bool const vadResult, int const frameIdx, fft frameSpec)
{
	if (vadResult && modR != 1.0)
	{
		double ifft[frameSize];
		fftw_complex fft_mod[nyq] = { 0 };

		int maxIdx;

		if (modR <= 1.0) maxIdx = nyq;
		else maxIdx = floor(data.size() / (2.0*modR));

		for (int k = 0; k < maxIdx; k++)
		{
			fft_mod[static_cast<int>(modR*k)][0] += frameSpec.getReal(k);
			fft_mod[static_cast<int>(modR*k)][1] += frameSpec.getImag(k);
		}

		fftw_plan iplan = fftw_plan_dft_c2r_1d(frameSize, &fft_mod[0], ifft, FFTW_ESTIMATE);
		fftw_execute(iplan);
		fftw_destroy_plan(iplan);
		for (int k = 0; k < frameSize; k++) ifft[k] /= static_cast<double>(frameSize);
		copy(ifft, ifft + sizeof(ifft) / sizeof(ifft[0]), modOutput.begin() + (frameIdx*(frameSize - overlapSize)));
	}
	else if (vadResult && modR == 1.0)
	{
		copy(data.begin(), data.end(), modOutput.begin() + (frameIdx*(frameSize - overlapSize)));
	}
	else
	{
		fill(modOutput.begin() + (frameIdx*(frameSize - overlapSize)), modOutput.begin() + (((frameIdx + 1)*frameSize) - (frameIdx*overlapSize)), 0);
	}

}






int main()
{
	cout << "Processing..." << endl;
	//Load input data
	vector<double> r;
	string path = GetCurrentWorkingDir();
	    struct wavInfo input = readWav(path.append("/syncFiles/input.wav").c_str());
	path = GetCurrentWorkingDir();
	load_vec(path.append("/syncFiles/scale.txt"), r);

	//Remove DC offset from signal
	double dc = mean(input.data);
	for (vector<double>::iterator it = input.data.begin(); it != input.data.end(); ++it)
	{
		*it -= dc;
	}

	//Calculate number of 40 ms overlapping frames
	int numFrames = ceil((static_cast<double>(input.data.size() - frameSize) / static_cast<double>(frameSize - overlapSize)) + 1.0);

	//Calculate num of frames of silence, assume 5 seconds
	int delay = floor((Fs * 5.0) / static_cast<double>(frameSize - overlapSize));


	//Pad input with zeros if data is not an integer number of frames
	if (input.data.size() % (frameSize - overlapSize))
	{
		vector<double> zeroPad((((numFrames - 1)*(frameSize - overlapSize)) + frameSize) - input.data.size(), 0);
		input.data.insert(input.data.end(), zeroPad.begin(), zeroPad.end());
	}

	//Instantiate output arrays
	vector<double> outputVAD(input.data.size());
	vector<double> outputMOD(input.data.size());

	//Allocate memory for noise spectrum and frame VAD output
	vector<double> noiseSpectrum(nyq, 0.0); //absolute fft of all noise frames
	bool tempVadLogical;

	//Set thresholds for vad
	double eThresh = setThresh(input.data, delay, noiseSpectrum);

	for (int k = delay; k < numFrames - 1; k++)
	{
		vector<double> frame(&input.data[k*(frameSize - overlapSize)], &input.data[((k + 1)*frameSize) - (k*overlapSize)]);
		fft frameFFT = vad(frame, noiseSpectrum, eThresh, outputVAD, k, tempVadLogical);
		mod(frame, r[0], outputMOD, tempVadLogical, k, frameFFT);
	}

	//Write output .txt and .wav needed by GUI
	    path = GetCurrentWorkingDir();
	    save_vec(path.append("/syncFiles/input.txt"), input.data);

	    path = GetCurrentWorkingDir();
	    save_vec(path.append("/syncFiles/outputVAD.txt"), outputVAD);

	    path = GetCurrentWorkingDir();
	    save_vec(path.append("/syncFiles/outputMOD.txt"), outputMOD);

	    path = GetCurrentWorkingDir();
	    path.append("/syncFiles/output.wav");
	    writeWav(path.c_str(), input, outputMOD);

	 cout << "Audio processing has finished." << endl;

	return 0;
}



