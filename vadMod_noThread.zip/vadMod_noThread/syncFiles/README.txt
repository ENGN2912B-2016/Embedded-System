This syncFiles folder is here for debugging purposes when running the code in Eclipse.
This is not the folder that is actually getting synced when this project is running.